require('./bootstrap');

require('alpinejs');